from turtle import Turtle
class Scoreboard(Turtle):
    def __init__(self):
        super().__init__()
        self.penup()
        self.pensize(5)
        self.hideturtle()
        self.color("white")
        self.l_score=0
        self.r_score=0
        self.goto(-100,230)
        self.write(self.l_score,align="center",font=("Arial",40,"normal"))
        self.goto(100,230)
        self.write(self.r_score,align="center",font=("Arial",40,"normal"))
    def r_miss(self):
        if(self.l_score>2):
            self.clear()
            self.write("Left person won",align="center",font=("Arial",40,"normal"))
        else:
            self.l_score+=1
            self.clear()
            self.goto(-100,230)
            self.write(self.l_score,align="center",font=("Arial",40,"normal"))
            self.goto(100,230)
            self.write(self.r_score,align="center",font=("Arial",40,"normal"))
    def l_miss(self):
        if(self.r_score>2):
            self.clear()
            self.goto(0,0)
            self.write("Right person won",align="center",font=("Arial",80,"normal"))
        else:
            self.r_score+=1
            self.clear()
            self.goto(-100,230)
            self.write(self.l_score,align="center",font=("Arial",40,"normal"))
            self.goto(100,230)
            self.write(self.r_score,align="center",font=("Arial",40,"normal"))
