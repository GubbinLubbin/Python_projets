from turtle import Turtle

class Middle(Turtle):
    def __init__(self):
        super().__init__()
        self.hideturtle()
        self.penup()
        self.goto(0,300)
        self.pencolor("white")
        x=0
        y=400
        while(y>-400):
            self.pendown()
            y=y-20
            self.goto(x,y)
            self.penup()
            y=y-20
            self.goto(x,y)
class Upper(Turtle):
    def __init__(self):
        super().__init__()
        self.pensize(10)
        self.hideturtle()
        self.penup()
        self.goto(-300,400)
        self.pendown()
        self.goto(300,400)
        self.penup()
        self.goto(300,-400)
        self.pendown()
        self.goto(-300,-400)

        