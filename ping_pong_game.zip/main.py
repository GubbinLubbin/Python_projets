from turtle import Screen
from paddle import Paddle
from ball import Ball
from scoreboard import Scoreboard
from boundries import Middle,Upper
import time

game_is_on=True
screen=Screen()
screen.setup(800,600)
screen.bgcolor("black")
screen.title("The Ping Pong game")
ball=Ball()
screen.tracer(0)
l_paddle=Paddle((-370,0))
r_paddle=Paddle((370,0))
bich=Middle()
mathi=Upper()
scoreboard=Scoreboard()
screen.listen()
screen.onkey(l_paddle.up,"w")
screen.onkey(l_paddle.down,"s")
screen.onkey(r_paddle.up,"Up")
screen.onkey(r_paddle.down,"Down")
while game_is_on:
    screen.update()
    ball.move()
    if(ball.ycor()>280 or ball.ycor()<-280):
        ball.bounce()
    if((ball.distance(r_paddle)<50 and ball.xcor()>340) or (ball.distance(l_paddle)<50 and ball.xcor()<-340)):
        ball.p_bounce()    
    if(ball.xcor()>380):
        scoreboard.r_miss()
        ball.reset()
    if(ball.xcor()<-380):
        scoreboard.l_miss()
        ball.reset()
screen.exitonclick()