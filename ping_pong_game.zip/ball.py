from turtle import Turtle
import time

class Ball(Turtle):
    def __init__(self):
        super().__init__()
        self.shape("circle")
        self.color("white")
        self.x_move=10
        self.y_move=10
    def move(self):
        x=self.xcor()+self.x_move
        y=self.ycor()+self.y_move
        time.sleep(0.07)
        self.penup()
        self.speed(3)
        self.goto(x,y)
    def bounce(self):
        self.y_move*=-1
    def p_bounce(self):
        self.x_move*=-1
    def reset(self):
        self.goto(0,0)
        
