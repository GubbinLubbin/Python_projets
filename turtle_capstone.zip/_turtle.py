from turtle import Turtle

class _Turtle(Turtle):
    def __init__(self):
        super().__init__()
        self.shape("turtle")
        self.speed(2)
        self.color("white")
        self.penup()
        self.goto(0,-220)
        self.setheading(90)
    def go_up(self):
        self.forward(20)
    def go_down(self):
        self.setheading(270)
        self.forward(20)
        self.setheading(90)
    def win(self):
        self.clear()
        self.goto(0,0)
        self.write("Congratulations you win",align="center",font=("arial",30,"normal"))
    def lose(self):
        self.clear()
        self.goto(0,0)
        self.write("Sorry you lost!",align="center",font=("arial",30,"normal"))