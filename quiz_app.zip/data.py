question_data = [
    {"text": "The capital of France is Paris.", "answer": "True"},
    {"text": "The square root of 49 is 8.", "answer": "False"},
    {"text": "Python is a type of snake and a programming language.", "answer": "True"},
    {"text": "The Moon is a planet.", "answer": "False"},
    {"text": "5 multiplied by 6 equals 30.", "answer": "True"},
    {"text": "The chemical symbol for water is H2O.", "answer": "True"},
    {"text": "Light travels slower than sound.", "answer": "False"},
    {"text": "Mount Everest is the tallest mountain in the world.", "answer": "True"},
    {"text": "Humans have three hearts.", "answer": "False"},
    {"text": "Bats are mammals.", "answer": "True"},
]
