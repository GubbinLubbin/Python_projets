from turtle import Screen
from _turtle import _Turtle
from random_buses import Bus
import time
game_is_on=True

screen=Screen()
screen.tracer(0)
turtle=_Turtle()
bus=Bus()
screen.setup(600,500)
screen.bgcolor("black")
screen.listen()
screen.onkey(turtle.go_up,"w")
screen.onkey(turtle.go_down,"s")
while game_is_on:
    time.sleep(0.2)
    bus.create_bus()
    bus.move_bus()
    screen.update()
    if(turtle.ycor()>240):
        turtle.win()
        game_is_on=False
    for i in bus.all_buses:
        if(turtle.distance(i)<20):
            turtle.lose()
            game_is_on=False
screen.exitonclick()