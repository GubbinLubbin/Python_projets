from turtle import Turtle
class Paddle(Turtle):
    def __init__(self,position):
            super().__init__()
            self.shape("square")
            self.penup()
            self.color("white")
            self.shapesize(5,1)
            self.goto(position)
    def up(self):
        new_ycor=self.ycor()+20
        self.goto(self.xcor(),new_ycor)
    def down(self):
        new_ycor=self.ycor()-20
        self.goto(self.xcor(),new_ycor)