from tkinter import *
from tkinter import messagebox
import random
import json
#Generate random password and putting function
def random_pass():
    letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 
               'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+']

    nr_letters = random.randint(8, 10)  
    nr_symbols = random.randint(2, 4)
    nr_numbers = random.randint(2, 4)

    password_list = []

    for char in range(nr_letters):
        password_list.append(random.choice(letters))

    for char in range(nr_symbols):
        password_list += random.choice(symbols)

    for char in range(nr_numbers):
        password_list += random.choice(numbers)

    random.shuffle(password_list)

    pw = ""
    for char in password_list:
        pw += char

    pass_entry.delete(0, END)  # Added → clears old password before inserting new one
    pass_entry.insert(0, pw)   # Now works because pass_entry is defined earlier


#Add function
def save():
    website=website_entry.get()
    email=email_entry.get()
    password=pass_entry.get()
    new_data={
        website:{
            "Email":email,
            "Password":password
        }
    }
    if(len(website)==0 or len(email)==0 or len(password)==0):
        messagebox.showinfo(title="Oops",message="Make sure the field arent empty")
    else:   
            website_entry.delete(0,END)
            email_entry.delete(0,END)
            pass_entry.delete(0,END)
            with open("data.json","r") as data_file:
                data=json.load(data_file)
                data.update(new_data)
            with open("data.json","w") as data_file:
                json.dump(data,data_file,indent=4)


window=Tk()
window.title("The Password Storage and Generator")
window.config(padx=50,pady=50)
canvas=Canvas(height=200,width=200)
logo_img=PhotoImage(file="logo.png")
canvas.create_image(100,100,image=logo_img)
canvas.grid(row=0,column=1)
#Labels
website_label=Label(text="Website:")
website_label.grid(row=1)
email_label=Label(text="Email/Username:")
email_label.grid(row=2)
pass_label=Label(text="Password:")
pass_label.grid(row=3)

#Entries
website_entry=Entry(width=35)
website_entry.grid(row=1,column=1,columnspan=2)
website_entry.focus()
email_entry=Entry(width=35)
email_entry.grid(row=2,column=1,columnspan=2)

pass_entry=Entry(width=22)  
pass_entry.grid(row=3,column=1)

#Buttons
generate_pass_button=Button(text="Generate",width=10,command=random_pass)
generate_pass_button.grid(row=3,column=2)
add_button=Button(text="Add",width=32,command=save)
add_button.grid(row=4,column=1,columnspan=2)

window.mainloop()
