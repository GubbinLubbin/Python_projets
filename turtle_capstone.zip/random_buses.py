import random
from turtle import Turtle
colors=["red","blue","orange","pink","purple"]

class Bus:
    def __init__(self):
        self.all_buses=[]
    def create_bus(self):
        new_bus=Turtle()
        new_bus.penup()
        new_bus.shape("square")
        new_bus.shapesize(2,1)
        new_bus.color(random.choice(colors))
        random_y=random.randint(-160,200)
        new_bus.goto(300,random_y)
        self.all_buses.append(new_bus)
    def move_bus(self):
        for bus in self.all_buses:
            bus.backward(20)